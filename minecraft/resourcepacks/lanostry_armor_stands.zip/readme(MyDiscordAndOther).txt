Thanks for using my resourcepack!

You should know that I am against using my 
resourcepacks and other products on paid builds or servers.

If you are interested in my services as a texturer or modeller,
you can go to my discord: (I also look forward to hearing from you for 
communication or ideas for future projects.)

https://discord.gg/mThvczzpuV

Donation and exclusive content: 

https://boosty.to/lanostry

<3

